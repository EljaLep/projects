INSERT INTO courses (name)
VALUES ('Web Software Development');

INSERT INTO courses ( name)
VALUES ('Device-Agnostic Design');