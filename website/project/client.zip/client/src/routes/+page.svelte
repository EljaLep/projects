<script>

</script>

<h1 class="text-2xl">Welcome!</h1>

<!--<a href="/courses">Courses</a>-->
<!--
<form class="space-y-4" method="POST" action="http://localhost:8000/api/courses/1/questions/2/answers">
  
  <button class="w-full btn preset-filled-primary-500" type="submit">
    submit
  </button>
</form>-->