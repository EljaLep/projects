export async function load({ params }) {
  return params;
}