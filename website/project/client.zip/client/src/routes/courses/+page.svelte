<script>
  import Courses from "$lib/components/Courses.svelte";
</script>

<Courses />