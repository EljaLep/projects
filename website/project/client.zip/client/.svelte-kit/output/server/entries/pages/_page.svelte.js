import { C as pop, z as push, G as ensure_array_like, I as store_get, J as unsubscribe_stores } from "../../chunks/index.js";
import { e as escape_html } from "../../chunks/escaping.js";
const replacements = {
  translate: /* @__PURE__ */ new Map([
    [true, "yes"],
    [false, "no"]
  ])
};
function attr(name, value, is_boolean = false) {
  if (value == null || !value && is_boolean) return "";
  const normalized = name in replacements && replacements[name].get(value) || value;
  const assignment = is_boolean ? "" : `="${escape_html(normalized, true)}"`;
  return ` ${name}${assignment}`;
}
const PUBLIC_API_URL = "http://localhost:8000";
const readQuestions = async () => {
  const response = await fetch(`${PUBLIC_API_URL}/courses/1/questions`);
  return await response.json();
};
const createQuestion = async (title_, text_) => {
  const oldlist = await readQuestions();
  const newId = oldlist.length + 1;
  const newQuestion = {
    id: newId,
    title: title_,
    text: text_,
    upvotes: 0
  };
  const response = await fetch(`${PUBLIC_API_URL}/courses/1/questions`, {
    method: "POST",
    body: JSON.stringify(newQuestion)
  });
  return await response.json();
};
const removeQuestion = async (id_) => {
  const response = await fetch(`${PUBLIC_API_URL}/courses/1/questions/${id_}`, {
    method: "DELETE"
  });
  return await response.json();
};
const upvoteQuestion = async (id_) => {
  const response = await fetch(`${PUBLIC_API_URL}/courses/1/questions/${id_}`, {
    method: "POST"
  });
  return await response.json();
};
let questionState = [];
const useQuestionState = () => {
  return {
    get questions() {
      return questionState;
    },
    update: async () => {
      const response = await readQuestions();
      questionState = await response;
    },
    add: async (question) => {
      const newQ = await createQuestion(question.title, question.text);
      questionState.push(newQ);
    },
    upvote: async (id) => {
      const newQuestion = await upvoteQuestion(id);
      questionState = questionState.map((element) => element.id == id ? newQuestion : element);
    },
    remove: async (id) => {
      await removeQuestion(id);
      const questionState2 = questionState2.filter((element) => element.id !== id);
    }
  };
};
function QuestionForm($$payload, $$props) {
  push();
  $$payload.out += `<form><label for="title">Title</label> <input id="title" name="title" type="text" placeholder="Enter the title of a new question"/> <br/> <label for="text_area">Text</label> <textarea id="text_area" name="text_area" placeholder="Enter question"></textarea> <br/> <input type="submit" value="Add Question"/></form>`;
  pop();
}
function QuestionItem($$payload, $$props) {
  push();
  let { question } = $$props;
  $$payload.out += `<label${attr("for", question.id)}><h4>${escape_html(question.title)}</h4> <h5>(Upvotes: ${escape_html(question.upvotes)})</h5> <p>${escape_html(question.text_area)}</p></label> <button>Upvote</button> <button>Delete</button>`;
  pop();
}
function QuestionList($$payload, $$props) {
  push();
  var $$store_subs;
  let questionState2 = useQuestionState();
  const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$questionState", questionState2));
  $$payload.out += `<ul><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let question = each_array[$$index];
    $$payload.out += `<li>`;
    QuestionItem($$payload, { question });
    $$payload.out += `<!----></li>`;
  }
  $$payload.out += `<!--]--></ul>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function Questions($$payload) {
  $$payload.out += `<h1>Questions</h1> <h2>Add Question</h2> `;
  QuestionForm($$payload);
  $$payload.out += `<!----> <h2>Existing questions</h2> `;
  QuestionList($$payload);
  $$payload.out += `<!---->`;
}
function _page($$payload) {
  Questions($$payload);
}
export {
  _page as default
};
