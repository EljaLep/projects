

export const index = 2;
export const imports = [];
export const stylesheets = [];
export const fonts = [];
