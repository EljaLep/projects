import * as universal from '../entries/pages/_layout.js';

export const index = 0;
export { universal };
export const universal_id = "src/routes/+layout.js";
export const imports = [];
export const stylesheets = [];
export const fonts = [];
